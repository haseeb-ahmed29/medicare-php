<?php
$name= "john doe";
$email= "JOHN@GMAIL.COM";
$age= 77;
$ispresent= true;
//console.log(name + email)
echo "hello php";
echo "<br>";
echo "learn php";
echo "<br>";
echo $name ."email: " . $email . " ". $age . " ". $ispresent;
echo "<br>";
//string methods
echo "length".strlen($name);
echo "<br>";
echo "upper".strtoupper($name);
echo "<br>";
echo "lower".strtolower($email);
echo "<br>";
echo "ucfirst".ucfirst($name);
echo "<br>";
echo "ucwords".ucwords($name);
echo "<br>";
echo "substr ".substr($name,2,5);
echo "<br>";
echo "position ".strpos($name,"doe");
echo "<br>";
echo "replace ".str_replace("doe","david",$name);
echo "<br>";
//regexp method
// preg_match()
$string="the quick brown fox jumps over the lazy dog";
$regexp_result= preg_match("/hello world/",$string);
if($regexp_result){
echo "pattern found";
}
else{
   echo "pattern not found"; 
}
//operators
echo "<br>";
$a=10;
$b=20;
// echo "sum". $a+$b;
echo "<br>";
//$a= $a+$b
// echo "assignment". $a+=$b;
echo "<br>";
// echo "comparision". $a!=$b;
echo "<br>";
// echo "comparision". $a>=$b;
//10>=20
echo "<br>";
// echo "comparision". $a<=$b;
echo "<br>";
echo "logical operators". $a==$b&&$a==$b;
echo "<br>";
echo "logical operators". $a==$b||$a<=$b;
echo "<br>";
//switch case
$fruit="apple";
switch($fruit){
    case "banana": echo "you chose banana";
    break;
    case "apple": echo "you chose apple";
    break;
    case "melon": echo "you chose melon";
    break;
    default : echo "you chose wrong fruit";
    break;
}
//looping statements
echo "<br>";
//while loop, for loop
$count=1;
while($count<=5){
    echo "count" . $count . "<br>";
    $count++;
}
//for loop
for($i=1;$i<=5;$i++){
echo "for loop".$i . "<br>";
}
echo "<br>";
//foreach
// $colors=["red","blue","orange"];
$color=array("red","blue","orange");

echo "<br>";
foreach($color as $item){
echo "color: ".$item. "<br>";
}
//indexed array , associative array, multidimensional array
$colors=array("red","blue","orange");
echo "indexed array".$colors[0];
echo "<br>";
$person=array(
    "name"=>"john",
     "age"=>25, 
     "city"=>"new york"
     );
     echo "associative array".$person["name"];
echo "<br>";
     foreach($person as $item=>$value){
echo $item ." ".$value . "<br>";
}
//multi
$people= array(
   array("john", 25, "new york" ),
   array("alice", 25, "isb" ),
   array("david", 20, "new york" )

);
    echo "multi array".$people[1][2];
    echo "<br>";
    echo "multi array".$people[2][1];
echo "<br>";

 foreach($people as $person){
//   print_r($person);
  foreach($person as $details){
    echo $details;
  }
  echo "<br>";  
}

$details=['john',123, true,'newyork'];
//array methods
array_push($details,1736273627,"red");
print_r($details);
echo "<br>"; 
array_pop($details);
print_r($details);

echo "<br>"; 

echo array_search("john",$details);
 echo "<br>"; 

function addnumbers($a,$b){
$sum= $a+$b;
echo "the sum is ". $sum;
}
addnumbers(5,1);
 echo "<br>";
addnumbers(7,1);
 echo "<br>";
addnumbers(8,1);

?>