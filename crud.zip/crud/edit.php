<?php
include('db.php');

$id = (int)($_GET['id'] ?? 0);

$stmt = mysqli_prepare($conn, "SELECT * FROM students WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);
mysqli_stmt_execute($stmt);
$row = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Edit Student</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body class="bg-light">

  <nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
      <span class="navbar-brand mb-0 h1">Student Manager</span>
    </div>
  </nav>

  <div class="container pb-5" style="max-width:560px">
    <?php if ($row) { ?>
      <div class="card shadow-sm">
        <div class="card-header bg-white fw-semibold">Edit student</div>
        <div class="card-body">
          <form action="update.php" method="post">
            <input type="hidden" name="id" value="<?php echo (int)$row['id']; ?>">

            <div class="mb-3">
              <label for="name" class="form-label">Name</label>
              <input type="text" class="form-control" id="name" name="name" maxlength="100"
                     value="<?php echo htmlspecialchars($row['name']); ?>" required>
            </div>

            <div class="mb-3">
              <label for="phone" class="form-label">Phone</label>
              <input type="tel" class="form-control" id="phone" name="phone" maxlength="20"
                     value="<?php echo htmlspecialchars($row['phone']); ?>" required>
            </div>

            <div class="d-flex gap-2">
              <button type="submit" class="btn btn-success">Save changes</button>
              <a href="managestudents.php" class="btn btn-outline-secondary">Cancel</a>
            </div>
          </form>
        </div>
      </div>
    <?php } else { ?>
      <div class="alert alert-danger">
        Student not found.
        <a href="managestudents.php" class="alert-link">Back to students</a>
      </div>
    <?php } ?>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>
