<?php
//dbconnection
$conn= mysqli_connect("localhost","root","","student_db");

//check connection
if(!$conn){
die("coonection failed".mysqli_connect_error());
}
//get form data
$name= $_POST["name"]; 
$phone= $_POST["phone"]; 

// echo $name;
// echo $phone;

//sql
$insertquery= "insert into students(name,phone) values('$name',$phone)";

//execute the query

$runquery= mysqli_query($conn,$insertquery);

if($runquery){
    echo "data inserted";
}
else{
    echo "error".mysqli_error($conn);
}
?>