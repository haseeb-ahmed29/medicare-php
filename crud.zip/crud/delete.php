<?php
include('db.php');

$id = (int)($_GET['id'] ?? 0);

$stmt = mysqli_prepare($conn, "DELETE FROM students WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $id);

if (mysqli_stmt_execute($stmt)) {
    header("Location: managestudents.php");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
}
