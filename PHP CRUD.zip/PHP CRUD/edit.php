<?php
include('db.php');
//get form data
$userid= $_GET['id']; //3

//sql
$fetchquery= "select * from students where id='$userid'";

//execute the query

$runquery= mysqli_query($conn,$fetchquery);

if($runquery){
   $row=mysqli_fetch_assoc($runquery);
//    print_r($row);
}
else{
    echo "error".mysqli_error($conn);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body>
    <div class="container py-5">
     <h2 class="mt-2">EDIT STUDENT</h2>
     <?php if($row){?>
        <form action="update.php" method="post">
       
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
         <label for="">name</label>
        <input type="text" name="name" value="<?php echo $row['name'] ?>">
          <label for="">phone</label>
        <input type="text" name="phone" value="<?php echo $row['phone'] ?>">
        <button type='submit' class='btn btn-success'>update</button>
        </form>
        
   <?php } ?>



    </div>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>