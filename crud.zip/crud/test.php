<?php

// $name=$_POST["name"]; //hania
// $name=$_GET["name"]; //hania
$name=$_REQUEST["name"]; //hania
echo $name;
?>