<?php
include('db.php');
//get form data
$userid= $_GET['id']; //3

// echo $name;
// echo $phone;

//sql
$deletequery= "delete from students where id='$userid'";

//execute the query

$runquery= mysqli_query($conn,$deletequery);

if($runquery){
     header("Location:managestudents.php");}

else{
    echo "error".mysqli_error($conn);
}
?>