<?php

include('db.php');
//get form data
$name= $_POST["name"]; 
$phone= $_POST["phone"]; 

// echo $name;
// echo $phone;

//sql
$insertquery= "insert into students(name,phone) values('$name',$phone)";

//execute the query

$runquery= mysqli_query($conn,$insertquery);

if($runquery){
    header("Location:managestudents.php");}
else{
    echo "error".mysqli_error($conn);
}
?>