<?php
include('db.php');

// Form data
$name  = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone'] ?? '');

if ($name === '' || $phone === '') {
    die("Name and phone are required. <a href='managestudents.php'>Go back</a>");
}

// Prepared statement (SQL injection se bachata hai)
$stmt = mysqli_prepare($conn, "INSERT INTO students (name, phone) VALUES (?, ?)");
mysqli_stmt_bind_param($stmt, "ss", $name, $phone);

if (mysqli_stmt_execute($stmt)) {
    header("Location: managestudents.php");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
}
