-- Step 1: Database banao
CREATE DATABASE IF NOT EXISTS student_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_general_ci;

USE student_db;

-- Step 2: Table banao
CREATE TABLE IF NOT EXISTS students (
  id         INT(11)      NOT NULL AUTO_INCREMENT,
  name       VARCHAR(100) NOT NULL,
  phone      VARCHAR(20)  NOT NULL,
  created_at TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

-- Step 3 (optional): Test data
INSERT INTO students (name, phone) VALUES
  ('Ali Khan',    '03001234567'),
  ('Sara Ahmed',  '03111234567'),
  ('Hamza Malik', '03211234567');
