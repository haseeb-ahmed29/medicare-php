<?php
include('db.php');

// Form data
$id    = (int)($_POST['id'] ?? 0);
$name  = trim($_POST['name'] ?? '');
$phone = trim($_POST['phone'] ?? '');

if ($id === 0 || $name === '' || $phone === '') {
    die("Invalid data. <a href='managestudents.php'>Go back</a>");
}

// UPDATE query (pehle yahan INSERT likha tha, wo galat tha)
$stmt = mysqli_prepare($conn, "UPDATE students SET name = ?, phone = ? WHERE id = ?");
mysqli_stmt_bind_param($stmt, "ssi", $name, $phone, $id);

if (mysqli_stmt_execute($stmt)) {
    header("Location: managestudents.php");
    exit;
} else {
    echo "Error: " . mysqli_error($conn);
}
