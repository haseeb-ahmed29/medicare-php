<?php
include('db.php');
//sql
$insertquery= "select * from students";
//execute the query
$runquery= mysqli_query($conn,$insertquery);
?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
  </head>
  <body>
    <div class="container py-5">
           <h1 class="text-center">MANAGE STUDENTS</h1>
     <h1>ADD STUDENT</h1>
    <form action="insert.php" method="post">
        name:
        <input type="text" name="name"> 
        phone:
        <input type="number" name="phone" min=0> 
        <button type="submit" class="btn btn-success">ADD</button>
    </form>
     <h1 class="mt-5">ALL STUDENTS</h1>
     <table class="table table-bordered table-hover bg-white shadow-sm">
   <thead class="table-dark">
       <tr>
        <th>ID</th>
        <th>name</th>
        <th>phone</th>
        <th>Actions</th>
       </tr>
   </thead>
   <tbody>
   <?php
   $rows= mysqli_num_rows($runquery);
// echo $rows;
if($rows>0){
//     $data= mysqli_fetch_assoc($runquery);
// print_r($data);
while($data= mysqli_fetch_assoc($runquery)){
echo "<tr>";
echo "<td>".$data['id']."</td>";
echo "<td>".$data['name']."</td>";
echo "<td>".$data['phone']."</td>";
echo "<td>
<a href='edit.php?id=".$data['id']."' class='btn btn-warning'>edit</a>
<a href='delete.php?id=".$data['id']."' class='btn btn-danger'>delete</a>
</td>";
}
}
else{
    echo "no data found";
}
?>
   </tbody>
     </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
  </body>
</html>