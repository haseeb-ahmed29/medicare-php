<?php
include('db.php');

$result = mysqli_query($conn, "SELECT * FROM students ORDER BY id DESC");
$total  = $result ? mysqli_num_rows($result) : 0;
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Manage Students</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-sRIl4kxILFvY47J16cr9ZwB07vP4J8+LH7qKQnuqkuIAvNWLzeN8tE5YBujZqJLB" crossorigin="anonymous">
</head>
<body class="bg-light">

  <nav class="navbar navbar-dark bg-dark mb-4">
    <div class="container">
      <span class="navbar-brand mb-0 h1">Student Manager</span>
      <span class="navbar-text"><?php echo $total; ?> student<?php echo $total == 1 ? '' : 's'; ?></span>
    </div>
  </nav>

  <div class="container pb-5">

    <!-- Add student -->
    <div class="card shadow-sm mb-4">
      <div class="card-header bg-white fw-semibold">Add student</div>
      <div class="card-body">
        <form action="insert.php" method="post" class="row g-3">
          <div class="col-md-5">
            <label for="name" class="form-label">Name</label>
            <input type="text" class="form-control" id="name" name="name" maxlength="100" placeholder="e.g. Ali Khan" required>
          </div>
          <div class="col-md-5">
            <label for="phone" class="form-label">Phone</label>
            <input type="tel" class="form-control" id="phone" name="phone" maxlength="20" placeholder="e.g. 03001234567" required>
          </div>
          <div class="col-md-2 d-flex align-items-end">
            <button type="submit" class="btn btn-success w-100">Add student</button>
          </div>
        </form>
      </div>
    </div>

    <!-- Students table -->
    <div class="card shadow-sm">
      <div class="card-header bg-white fw-semibold">All students</div>
      <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
          <thead class="table-dark">
            <tr>
              <th style="width:80px">ID</th>
              <th>Name</th>
              <th>Phone</th>
              <th class="text-end" style="width:180px">Actions</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($total > 0) { while ($data = mysqli_fetch_assoc($result)) { ?>
              <tr>
                <td><?php echo (int)$data['id']; ?></td>
                <td><?php echo htmlspecialchars($data['name']); ?></td>
                <td><?php echo htmlspecialchars($data['phone']); ?></td>
                <td class="text-end">
                  <a href="edit.php?id=<?php echo (int)$data['id']; ?>" class="btn btn-sm btn-warning">Edit</a>
                  <a href="delete.php?id=<?php echo (int)$data['id']; ?>" class="btn btn-sm btn-danger"
                     onclick="return confirm('Delete this student?');">Delete</a>
                </td>
              </tr>
            <?php } } else { ?>
              <tr>
                <td colspan="4" class="text-center text-muted py-4">No students yet. Add the first one above.</td>
              </tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>

  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.8/dist/js/bootstrap.bundle.min.js" integrity="sha384-FKyoEForCGlyvwx9Hj09JcYn3nv7wiPVlz7YYwJrWVcXK/BmnVDxM+D2scQbITxI" crossorigin="anonymous"></script>
</body>
</html>
