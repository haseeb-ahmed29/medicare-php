<?php

//dbconnection
$conn= mysqli_connect("localhost","root","","student_db");

//check connection
if(!$conn){
die("coonection failed".mysqli_connect_error());
}

?>